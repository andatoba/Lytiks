# Sistema Lytiks - Arquitectura Completa

## 📋 Descripción General

El sistema Lytiks consta de 3 componentes principales que se despliegan juntos usando Docker Compose:

1. **Backend (Spring Boot)** - API REST para la aplicación móvil y el portal web
2. **Portal Web (Flutter Web)** - Interfaz administrativa web
3. **Base de Datos (MySQL 8.0)** - Almacenamiento de datos

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│                     Docker Network                          │
│                    (lytiks-network)                         │
│                                                             │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────┐ │
│  │   MySQL      │◄─────│   Backend    │◄─────│  Portal  │ │
│  │   Puerto:    │      │   Spring     │      │   Web    │ │
│  │   3307→3306  │      │   Boot       │      │  Flutter │ │
│  └──────────────┘      │   Puerto:    │      │  Puerto: │ │
│                        │   8081→8080  │      │  8082→80 │ │
│                        └──────────────┘      └──────────┘ │
└─────────────────────────────────────────────────────────────┘
         ▲                      ▲                      ▲
         │                      │                      │
         └──────────────────────┴──────────────────────┘
              Accesible desde localhost o IP externa
```

## 🔄 Compatibilidad Backend

### El Portal Web utiliza los MISMOS endpoints que la aplicación móvil:

**Autenticación:**
- `POST /api/auth/login` - Login de usuarios
- `POST /api/auth/logout` - Cierre de sesión

**Clientes:**
- `GET /api/clients` - Listar clientes
- `GET /api/clients/{id}` - Obtener cliente
- `POST /api/clients` - Crear cliente
- `PUT /api/clients/{id}` - Actualizar cliente
- `DELETE /api/clients/{id}` - Eliminar cliente
- `GET /api/clients/stats` - Estadísticas (totalClients, activeClients, totalHectareas)

**Auditorías:**
- `GET /api/audits` - Listar auditorías
- `GET /api/audits/{id}` - Obtener auditoría
- `POST /api/audits` - Crear auditoría
- `GET /api/audits/stats` - Estadísticas (totalAudits, todayAudits, pendingAudits, completedAudits)

**Sigatoka:**
- `POST /api/sigatoka/crear-evaluacion` - Crear evaluación
- `POST /api/sigatoka/{id}/lotes` - Agregar lotes
- `POST /api/sigatoka/lotes/{id}/muestras` - Agregar muestras
- `GET /api/sigatoka/evaluaciones` - Listar evaluaciones

**Productos:**
- `GET /api/productos` - Listar productos
- `GET /api/productos/{id}` - Obtener producto

**Usuarios:**
- `GET /api/usuarios` - Listar usuarios
- `POST /api/usuarios` - Crear usuario

## 🚀 Despliegue con Docker Compose

### Prerrequisitos

```bash
# Verificar Docker
docker --version

# Verificar Docker Compose
docker-compose --version
```

### Despliegue Completo

```bash
# Ir al directorio del docker-compose
cd C:\Users\WELLINGTON\Desktop\Lytiks\Lytiks\backend_new

# Construir y levantar todos los servicios
docker-compose up -d

# Ver logs en tiempo real
docker-compose logs -f

# Ver logs de un servicio específico
docker-compose logs -f backend
docker-compose logs -f portal-web
docker-compose logs -f mysql
```

### Orden de Inicio

Docker Compose levanta los servicios en este orden automáticamente:

1. **MySQL** - Se inicia primero y espera hasta estar "healthy" (healthcheck)
2. **Backend** - Se inicia después de que MySQL esté listo
3. **Portal Web** - Se inicia después de que el Backend esté disponible

## 🌐 URLs de Acceso

### En Desarrollo Local

- **Portal Web**: http://localhost:8082
- **Backend API**: http://localhost:8081
- **MySQL**: localhost:3307

### En Servidor de Producción (5.161.198.89)

- **Portal Web**: http://5.161.198.89:8082
- **Backend API**: http://5.161.198.89:8081
- **MySQL**: 5.161.198.89:3307

## 🔧 Configuración Dinámica del Backend

El Portal Web se configura automáticamente según el entorno:

### En Docker (Contenedores)
```yaml
environment:
  - BACKEND_URL=http://backend:8080
```
El portal usa el nombre del servicio Docker (`backend`) para comunicarse internamente.

### Fuera de Docker (Desarrollo Local)
El portal usa la URL hardcodeada: `http://5.161.198.89:8081`

## 📦 Servicios en docker-compose.yml

### Backend
```yaml
backend:
  build: .
  ports: ["8081:8080"]
  depends_on: [mysql]
  environment:
    - SPRING_DATASOURCE_URL=jdbc:mysql://lytiks-new-mysql:3306/lytiks_db
    - SPRING_DATASOURCE_USERNAME=lytiks_user
    - SPRING_DATASOURCE_PASSWORD=lytiks_pass
```

### Portal Web
```yaml
portal-web:
  build: ../../Portal_lytiks
  ports: ["8082:80"]
  depends_on: [backend]
  environment:
    - BACKEND_URL=http://backend:8080
```

### MySQL
```yaml
mysql:
  image: mysql:8.0
  ports: ["3307:3306"]
  environment:
    - MYSQL_DATABASE=lytiks_db
    - MYSQL_USER=lytiks_user
    - MYSQL_PASSWORD=lytiks_pass
```

## 🛠️ Comandos Útiles

### Ver Estado de los Contenedores
```bash
docker-compose ps
```

### Detener Todos los Servicios
```bash
docker-compose down
```

### Detener y Eliminar Volúmenes (CUIDADO: Borra la BD)
```bash
docker-compose down -v
```

### Reconstruir un Servicio
```bash
# Reconstruir solo el backend
docker-compose build backend

# Reconstruir solo el portal
docker-compose build portal-web

# Reconstruir todo
docker-compose build
```

### Reiniciar un Servicio
```bash
docker-compose restart backend
docker-compose restart portal-web
docker-compose restart mysql
```

### Ver Logs de un Servicio
```bash
docker-compose logs -f backend --tail=100
```

### Entrar a un Contenedor
```bash
# Backend
docker exec -it lytiks-new-backend bash

# Portal Web
docker exec -it lytiks-portal-web sh

# MySQL
docker exec -it lytiks-new-mysql mysql -u lytiks_user -p
```

## 🔄 Workflow de Desarrollo

### 1. Desarrollar Localmente

**Backend:**
```bash
cd backend_new
mvn clean package
java -jar target/lytiks-backend-0.0.1-SNAPSHOT.jar
```

**Portal Web:**
```bash
cd Portal_lytiks
flutter run -d chrome
```

### 2. Desplegar con Docker

```bash
cd backend_new

# Reconstruir con cambios
docker-compose build

# Desplegar
docker-compose up -d

# Verificar
docker-compose ps
docker-compose logs -f
```

## 📱 Aplicación Móvil

La aplicación móvil Flutter (Lytiks/) se conecta al mismo backend:
- Usa los mismos endpoints REST
- Comparte la misma base de datos
- Autenticación compatible

**Para generar APK:**
```bash
cd Lytiks
flutter build apk --release
```

El APK estará en: `build/app/outputs/flutter-apk/app-release.apk`

## 🔐 Seguridad

### Credenciales de Base de Datos
- Usuario: `lytiks_user`
- Contraseña: `lytiks_pass`
- Base de datos: `lytiks_db`

### Usuarios de Prueba
- Usuario: `testop`
- Rol: OPERADOR

## 🐛 Troubleshooting

### El Portal no se conecta al Backend

**Síntoma:** Error de conexión en el portal web

**Solución:**
```bash
# Verificar que el backend está corriendo
docker-compose ps

# Ver logs del backend
docker-compose logs backend

# Reiniciar el portal
docker-compose restart portal-web
```

### MySQL no inicia

**Síntoma:** Backend no puede conectarse a la BD

**Solución:**
```bash
# Ver logs de MySQL
docker-compose logs mysql

# Recrear el contenedor de MySQL
docker-compose stop mysql
docker-compose rm mysql
docker-compose up -d mysql
```

### El Backend no compila

**Solución:**
```bash
# Compilar localmente primero
cd backend_new
mvn clean package -DskipTests

# Si funciona, reconstruir la imagen
docker-compose build backend
docker-compose up -d backend
```

### Puerto ya en uso

**Síntoma:** Error "port is already allocated"

**Solución:**
```bash
# Encontrar el proceso usando el puerto
netstat -ano | findstr :8081
netstat -ano | findstr :8082
netstat -ano | findstr :3307

# Matar el proceso o cambiar el puerto en docker-compose.yml
```

## 📊 Monitoreo

### Ver Uso de Recursos
```bash
docker stats
```

### Ver Red
```bash
docker network inspect lytiks-network
```

### Ver Volúmenes
```bash
docker volume ls
docker volume inspect backend_new_mysql-data-new
```

## 🔄 Actualización en Producción

```bash
# 1. Hacer backup de la BD
docker exec lytiks-new-mysql mysqldump -u lytiks_user -plytiks_pass lytiks_db > backup.sql

# 2. Detener servicios
docker-compose down

# 3. Actualizar código (git pull o copiar archivos)

# 4. Reconstruir
docker-compose build

# 5. Iniciar
docker-compose up -d

# 6. Verificar
docker-compose logs -f
```

## 📝 Notas Importantes

1. ✅ El Portal Web y la App Móvil usan el **mismo backend**
2. ✅ Comparten la **misma base de datos**
3. ✅ Los endpoints son **100% compatibles**
4. ✅ Con `docker-compose up` se levanta **todo el sistema** (Backend + Portal + MySQL)
5. ✅ La red interna de Docker permite comunicación entre contenedores
6. ✅ Los puertos expuestos permiten acceso externo
