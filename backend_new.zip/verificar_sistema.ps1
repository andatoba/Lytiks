# Script de verificacion del sistema Lytiks

Write-Host "Verificando configuracion del sistema Lytiks..." -ForegroundColor Cyan
Write-Host ""

$errores = 0

# 1. Verificar Docker
Write-Host "1. Verificando Docker..." -ForegroundColor Yellow
if (Get-Command docker -ErrorAction SilentlyContinue) {
    $dockerVersion = docker --version
    Write-Host "   OK Docker instalado: $dockerVersion" -ForegroundColor Green
} else {
    Write-Host "   ERROR Docker NO esta instalado" -ForegroundColor Red
    $errores++
}

# 2. Verificar Docker Compose
Write-Host "2. Verificando Docker Compose..." -ForegroundColor Yellow
if (Get-Command docker-compose -ErrorAction SilentlyContinue) {
    $composeVersion = docker-compose --version
    Write-Host "   OK Docker Compose instalado: $composeVersion" -ForegroundColor Green
} else {
    Write-Host "   ERROR Docker Compose NO esta instalado" -ForegroundColor Red
    $errores++
}

# 3. Verificar archivos necesarios
Write-Host "3. Verificando estructura de archivos..." -ForegroundColor Yellow

$archivosNecesarios = @(
    "docker-compose.yml",
    "Dockerfile",
    "pom.xml"
)

foreach ($archivo in $archivosNecesarios) {
    if (Test-Path $archivo) {
        Write-Host "   OK $archivo existe" -ForegroundColor Green
    } else {
        Write-Host "   ERROR $archivo NO existe" -ForegroundColor Red
        $errores++
    }
}

# 4. Verificar Portal_lytiks
Write-Host "4. Verificando Portal_lytiks..." -ForegroundColor Yellow
if (Test-Path "..\..\Portal_lytiks\Dockerfile") {
    Write-Host "   OK Portal_lytiks/Dockerfile existe" -ForegroundColor Green
} else {
    Write-Host "   ERROR Portal_lytiks/Dockerfile NO existe" -ForegroundColor Red
    $errores++
}

if (Test-Path "..\..\Portal_lytiks\nginx.conf") {
    Write-Host "   OK Portal_lytiks/nginx.conf existe" -ForegroundColor Green
} else {
    Write-Host "   ERROR Portal_lytiks/nginx.conf NO existe" -ForegroundColor Red
    $errores++
}

if (Test-Path "..\..\Portal_lytiks\pubspec.yaml") {
    Write-Host "   OK Portal_lytiks/pubspec.yaml existe" -ForegroundColor Green
} else {
    Write-Host "   ERROR Portal_lytiks/pubspec.yaml NO existe" -ForegroundColor Red
    $errores++
}

# 5. Verificar configuracion del docker-compose
Write-Host "5. Verificando docker-compose.yml..." -ForegroundColor Yellow
$composeContent = Get-Content "docker-compose.yml" -Raw

if ($composeContent -match "backend:") {
    Write-Host "   OK Servicio 'backend' configurado" -ForegroundColor Green
} else {
    Write-Host "   ERROR Servicio 'backend' NO encontrado" -ForegroundColor Red
    $errores++
}

if ($composeContent -match "portal-web:") {
    Write-Host "   OK Servicio 'portal-web' configurado" -ForegroundColor Green
} else {
    Write-Host "   ERROR Servicio 'portal-web' NO encontrado" -ForegroundColor Red
    $errores++
}

if ($composeContent -match "mysql:") {
    Write-Host "   OK Servicio 'mysql' configurado" -ForegroundColor Green
} else {
    Write-Host "   ERROR Servicio 'mysql' NO encontrado" -ForegroundColor Red
    $errores++
}

if ($composeContent -match "lytiks-network") {
    Write-Host "   OK Red 'lytiks-network' configurada" -ForegroundColor Green
} else {
    Write-Host "   ERROR Red 'lytiks-network' NO encontrada" -ForegroundColor Red
    $errores++
}

# 6. Verificar compatibilidad de endpoints
Write-Host "6. Verificando compatibilidad de endpoints..." -ForegroundColor Yellow

$portalAuthService = Get-Content "..\..\Portal_lytiks\lib\services\auth_service.dart" -Raw

if ($portalAuthService -match "5.161.198.89:8081") {
    Write-Host "   OK Portal configurado para usar backend en 5.161.198.89:8081" -ForegroundColor Green
} else {
    Write-Host "   AVISO Portal NO apunta a 5.161.198.89:8081" -ForegroundColor Yellow
}

if ($portalAuthService -match "/api/auth/login") {
    Write-Host "   OK Endpoint /api/auth/login encontrado" -ForegroundColor Green
} else {
    Write-Host "   ERROR Endpoint /api/auth/login NO encontrado" -ForegroundColor Red
    $errores++
}

# Resumen
Write-Host ""
Write-Host "=" * 70 -ForegroundColor Cyan

if ($errores -eq 0) {
    Write-Host "VERIFICACION EXITOSA - Sistema listo para desplegar" -ForegroundColor Green
    Write-Host ""
    Write-Host "Para iniciar el sistema completo ejecuta:" -ForegroundColor Cyan
    Write-Host "   docker-compose up -d" -ForegroundColor White
    Write-Host ""
    Write-Host "Servicios que se levantaran:" -ForegroundColor Cyan
    Write-Host "   - MySQL          -> localhost:3307" -ForegroundColor White
    Write-Host "   - Backend API    -> localhost:8081" -ForegroundColor White
    Write-Host "   - Portal Web     -> localhost:8082" -ForegroundColor White
} else {
    Write-Host "VERIFICACION FALLO - $errores error(es) encontrado(s)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Por favor corrige los errores antes de continuar" -ForegroundColor Yellow
}

Write-Host "=" * 70 -ForegroundColor Cyan
Write-Host ""
