-- ============================================
-- Script para crear usuario ADMIN de prueba
-- Base de datos: lytiks_db
-- Fecha: 2026-01-05
-- ============================================

USE lytiks_db;

-- Paso 1: Verificar y crear rol ADMIN si no existe
-- ================================================
INSERT INTO is_roles (nombre, detalle, estado, fecha_ingreso)
SELECT 'ADMIN', 'Administrador del sistema con acceso completo al Portal Web', 'A', NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM is_roles WHERE nombre = 'ADMIN'
);

-- Verificar otros roles comunes
INSERT INTO is_roles (nombre, detalle, estado, fecha_ingreso)
SELECT 'OPERADOR', 'Operador del sistema con acceso a funciones operativas', 'A', NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM is_roles WHERE nombre = 'OPERADOR'
);

INSERT INTO is_roles (nombre, detalle, estado, fecha_ingreso)
SELECT 'TECNICO', 'Técnico de campo con acceso a auditorías y reportes', 'A', NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM is_roles WHERE nombre = 'TECNICO'
);

-- Paso 2: Crear usuario ADMIN de prueba
-- ======================================
-- Usuario: admin
-- Contraseña: admin123 (encriptada con AES)
-- Contraseña encriptada: fK3MJLqF8yGxKlqHqPmGMQ==

INSERT INTO is_usuarios (
    id_roles,
    usuario,
    clave,
    nombres,
    apellidos,
    correo,
    estado,
    fecha_ingreso
)
SELECT 
    (SELECT id_roles FROM is_roles WHERE nombre = 'ADMIN' LIMIT 1),
    'admin',
    'fK3MJLqF8yGxKlqHqPmGMQ==',
    'Administrador',
    'Sistema',
    'admin@lytiks.com',
    'A',
    NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM is_usuarios WHERE usuario = 'admin'
);

-- Paso 3: Verificar creación
-- ===========================
SELECT 
    u.id_usuarios,
    u.usuario,
    u.nombres,
    u.apellidos,
    r.nombre as rol,
    u.estado
FROM is_usuarios u
LEFT JOIN is_roles r ON u.id_roles = r.id_roles
WHERE u.usuario = 'admin';

-- ============================================
-- CREDENCIALES DEL USUARIO ADMIN:
-- ============================================
-- Usuario: admin
-- Contraseña: admin123
-- Rol: ADMIN
-- ============================================

-- Consultar todos los roles existentes
SELECT 
    id_roles,
    nombre,
    detalle,
    estado
FROM is_roles
ORDER BY nombre;

-- Consultar todos los usuarios activos con sus roles
SELECT 
    u.id_usuarios,
    u.usuario,
    u.nombres,
    u.apellidos,
    r.nombre as rol,
    u.correo,
    u.estado
FROM is_usuarios u
LEFT JOIN is_roles r ON u.id_roles = r.id_roles
WHERE u.estado = 'A'
ORDER BY r.nombre, u.usuario;
